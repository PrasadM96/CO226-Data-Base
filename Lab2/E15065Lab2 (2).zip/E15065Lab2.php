<html>
<head>
<style type="text/css">
	body{
		 border: 5px solid black;
		 height:500px;
		 padding:10px;
		 width:460px;
		 margin:auto;
		 margin-top:50px;
	}
	.text{
		font-style: italic;
		font-size: 18px;
	}
</style>
</head>

<body>
	<h1>Your Information System</h1>
	
	<p>Thank you, <?php echo $_POST["firstname"]; ?> for your perches from our site</p>
	
	<p>your item colour is : <?php echo $_POST["color"]?> & T-Shirt size :
	<?php 
		if(!empty($_POST["size"])){
			echo $_POST["size"];
		}
	?></p>
	
	<p>Selected items/item are:</p>
	<ul>
	<?php
	
		if(!empty($_POST["item"])){
			foreach($_POST["item"] as $item){
				echo '<p><li>'.$item.'</li></p>';
			}
		}
	?>
	</ul>
	
	<p>your items will be sent to:</p>
	<p class="text">
	
		
		<?php echo $_POST["firstname"] ." ". $_POST["lastname"]."<br>";?>
		<?php
		 if(!empty($_POST["address1"])){
				echo $_POST["address1"]."<br>";
		}
		?>
		
		<?php
		 if(!empty($_POST["address2"])){
				echo $_POST["address2"]."<br>";
		}
		?>
		
		<?php
		 if(!empty($_POST["address3"])){
				echo $_POST["address3"]."<br>";
		}
		?>
	</p>
	
	
	
	<?php
	if(!empty($_POST["comment3"])){
			echo "<p>Thank you for submitting your comments. We appreciate it. You said:</p>";
			echo "<p class='text'>".$_POST["comment3"]."</p>";
	}
	?>
	
</body>

</html>